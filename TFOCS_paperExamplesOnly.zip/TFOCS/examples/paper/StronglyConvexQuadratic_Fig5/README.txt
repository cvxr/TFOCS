This makes a simple problem,

min x'Qx

where we can control Q, and thus make it strongly convex if we want.

Used to make Figure 5 in the paper
